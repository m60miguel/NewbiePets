class APIPath {
  static String pet(String uid) => 'Users/$uid';
}
