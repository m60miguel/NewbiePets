import 'package:flutter/material.dart';
import 'package:newbiepets_flutter/pages/mypets.dart';
import 'package:newbiepets_flutter/services/auth.dart';

class ProfilePage extends StatefulWidget {
  ProfilePage({this.auth});
  final Auth auth;

  static Future<void> show(BuildContext context, {Auth auth}) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ProfilePage(auth: auth),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  ProfilePageState createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(
      slivers: <Widget>[
        SliverAppBar(
          leading: IconButton(
              icon: Icon(Icons.arrow_back_ios, size: 32),
              onPressed: () => Navigator.pop(context)),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.edit, color: Colors.white, size: 32),
              onPressed: () => {},
            )
          ],
          expandedHeight: 220.0,
          floating: true,
          pinned: true,
          snap: true,
          elevation: 50,
          backgroundColor: Colors.deepPurple,
          flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: Text('Mi Perfil',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.0,
                  )),
              background: Image.network(
                'https://picsum.photos/id/251/640/480',
                fit: BoxFit.cover,
              )),
        ),
        SliverList(
            delegate: SliverChildListDelegate([
          ListTile(
            title: new Center(child: new Text('Var Nombre')),
            subtitle: new Center(child: new Text('Nombre')),
          ),
          ListTile(
            title: new Center(child: new Text('Var Email')),
            subtitle: new Center(child: new Text('Email')),
          ),
          ListTile(
            title: new Center(child: new Text('Var Nombre')),
            subtitle: new Center(child: new Text('Direccion')),
          ),
          ListTile(
            title: new Center(child: new Text('Var Nombre')),
            subtitle: new Center(child: new Text('Telefono')),
          ),
          MaterialButton(
            height: 50,
            color: Colors.blueAccent,
            textColor: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.pets),
                Text(
                  '    Mis Mascotas    ',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Icon(Icons.pets),
              ],
            ),
            onPressed: () => {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => MyPetPage()))
            },
          )
        ]))
      ],
    ));
  }
}
